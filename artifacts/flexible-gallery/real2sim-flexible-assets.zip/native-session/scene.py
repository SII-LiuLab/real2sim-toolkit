"""Five flexible assets sharing a table; SI units, authored demo parameters.
Newton VBD dynamics. Materials are illustrative, not calibrated.
Cable ends are clamped; other assets are free to drag.
"""
from pathlib import Path
import robosimstudio as rss

HERE = Path(__file__).resolve().parent
physics = rss.replace(rss.GENERIC, substeps=24,
                      collision=rss.CollisionSpec(full_surface_contact=True))
scene = rss.Scene(cell="void", physics=physics, name="flexible_asset_gallery")
scene.add(rss.slab(name="table", half=(0.66, 0.48, 0.035),
                   at=(0, 0, 0.715), color=(0.49, 0.53, 0.58)))
for name, x, color, material in (
    ("jersey_cloth", -0.39, (0.18, 0.58, 0.89), rss.materials.SHIRT_JERSEY),
    ("terry_towel", 0.0, (0.86, 0.32, 0.24), rss.materials.TERRY_TOWELLING),
):
    scene.add(rss.post(name=f"{name}_stand", radius=0.035, half_height=0.065,
                       at=(x, 0.20, 0.815), color=(0.72, 0.74, 0.78)))
    scene.add(rss.sheet(name=name, size=(0.28, 0.28), cells=(22, 22),
                        at=(x - 0.14, 0.06, 0.91), material=material,
                        color=color, settle_frames=0))
scene.add(rss.sponge(name="foam_sponge", size=(0.20, 0.14, 0.075),
                     cells=(10, 7, 4), at=(0.38, 0.20, 0.80),
                     color=(0.96, 0.77, 0.18), settle_frames=0))
scene.add(rss.SoftSpec(
    name="rubber_ring", asset=rss.AssetSpec(path=str(HERE / "assets/o_ring.npz")),
    pose=(-0.37, -0.22, 0.82),
    material=rss.SoftMaterialSpec(young=8.0e4, poisson=0.35, density=600.0,
                                  stiffness_damping=0.005, particle_radius=0.003),
    color=(0.24, 0.74, 0.45), settle_frames=0,
))
for name, x in (("cable_left_stand", -0.08), ("cable_right_stand", 0.48)):
    scene.add(rss.post(name=name, radius=0.022, half_height=0.065,
                       at=(x, -0.22, 0.815), color=(0.72, 0.74, 0.78)))
scene.add(rss.rod(name="flexible_cable", length=0.56, radius=0.008,
                  segments=24, at=(-0.08, -0.22, 0.89), along=(1, 0, 0),
                  anchors=("start", "end"), color=(0.55, 0.32, 0.80)))
scene.add(rss.CameraSpec(name="overview", width=1280, height=900,
                         eye=(0.95, -1.35, 1.9), look_at=(0.0, 0.0, 0.80), fov_y=45))
BUILD = {"use_cuda_graph": False, "warmup": False}
