Real2sim 柔性资产示例包 / 2026-10-17

范围：五个程序化原生示例；不是从实拍照片/视频恢复的已标定物理模型。

assets/<name>/geometry.npz：初始参考顶点、三角面、四面体（适用时）、来源粒子 ID、质量以及展示时位置。
assets/<name>/rest.obj：初始参考网格。displayed.obj：已运行后的展示网格，不能当成无应力静止形状。
assets/<name>/metadata.json：原生 spec、尺寸、材料参数、约束和坐标说明。
flexible_cable 的 NPZ 另含 centerline、displayed_centerline、radius_m、source_body_ids；OBJ 是中心线扫掠的显示管面。
native-session/scene.py：复现完整同场景的权威源文件，依赖相对路径 assets/o_ring.npz。
references/：柔性重建、原生会话文档和运行依赖列表；licenses/：来源及许可证。

坐标：米、千克、秒；Z 向上；导出几何为世界坐标，台面 Z=0.75 m。
OBJ 仅供外观/几何检查，不携带本构、质量、约束和接触行为。重现动力学请使用原生场景。
没有将这些模型宣称为等价的 Isaac/USD/MJCF 柔性物理资产。

在已安装本项目 Real2sim（embedded RoboSim runtime + Newton 1.6.1）的环境中：
  real2sim agent --session native-session --device cuda:0 --renderer rtx --panels all --resume
  real2sim scene-run --session native-session --device cuda:0 --renderer rtx --steps 360 --camera overview --capture-every 4 --record --compact
第二条独立执行命令从初始状态构建，实际完成情况以生成报告和时间戳为准。
若使用源码安装，在 real2sim-toolkit 根目录按项目文档安装；依赖参考：
  uv pip install -e . -r requirements/studio.txt --override requirements/studio-overrides.txt
  RTX 还需 requirements/studio-rtx.txt。本 ZIP 不捆绑 GPU 驱动及整个模拟器。

本包材料为上游预设及演示假设；未做真实载荷拟合、独立轨迹验证或材料标定。
